
from time import sleep
import serial
ser = serial.Serial('COM5', 9600) # Establish the connection on a specific port
#counter = 32 # Below 32 everything in ASCII is gibberish
sleep(2)
print("finish sleep")

print(ser.read(5))
k=1
t=0
while True:
    #ind = input("enter somethiong  ")
    print ("you entered",ind)
    #ser.write("2".encode())
    ser.write(ind.encode("latin-1"))
    print((ser.read(1)).decode("latin-1"))
