import os
from time import sleep
import serial
ser = serial.Serial('COM4', 9600) 
sleep(2)
print("Initialized")

obj = open ("jal.png", "rb")
data = obj.read()
print(type(data))
print(data.decode('latin-1'))
print(os.path.getsize("images.jpg"))

#s = "AB©CDE"
#b=bytearray()
#b.extend(map(ord,s))

#with open("kal.jpg", "wb") as w:
#    w.write(data)

nos = ser.write(data)

print("")
print("i wrote", nos)
input()


