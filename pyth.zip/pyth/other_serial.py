
from time import sleep
import serial
ser = serial.Serial('COM4', 9600) 
sleep(2)
print("Initialized")

ser.write("HelloOJAS".encode())
input()
