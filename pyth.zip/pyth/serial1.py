
from time import sleep
import serial
ser = serial.Serial('COM4', 9600) # Establish the connection on a specific port
#counter = 32 # Below 32 everything in ASCII is gibberish
k=1
st=65
sleep(2)
print("booted")
print(ser.read(5))
while k<5:
     #print('justcheckina')
     ser.write(str(chr(st)).encode()) # Convert the decimal number to ASCII then send it to the Arduino
     carl = ser.read()
     #carl='fail'
     carl = carl.decode()
     print(carl) # Read the newest output from the Arduino
     k +=1
     st=st+1
kalos=input('enter pls')
