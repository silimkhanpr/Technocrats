
from time import sleep
import serial
ser = serial.Serial('COM4', 9600) # Establish the connection on a specific port
#counter = 32 # Below 32 everything in ASCII is gibberish
sleep(2)
print("finish sleep")

print(ser.read(5))
k=1
t=0
while k==1:
    #print("t is now")
    ser.write('5'.encode())
    print(ser.read(1))
    sleep(.51)
    #print(t)
    t=t+1
